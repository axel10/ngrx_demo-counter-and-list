import {Num} from '../models/num';
import {Action} from '@ngrx/store';

export const ADD_NUM = 'ADD_NUM';


export const modelNum = (state: Num = new Num(0), action: Action) => {
  switch (action.type) {
    case 'ADD_NUM':
      state.count++;
      return state;
    default:
      return state;
  }
};
