import {Item} from '../models/item';
import {Action} from '@ngrx/store';


export const modelNum = (state: Item[] = [], action: Action) => {
  switch (action.type) {
    case 'LOAD_SUCCESS':
      return state.push(new Item(1, '213'));
    default:
      return state;
  }
};
