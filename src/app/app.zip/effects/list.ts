import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Observable} from 'rxjs/Observable';
import {Action} from '@ngrx/store';
import {mergeMap} from 'rxjs/operator/mergeMap';
import {map} from 'rxjs/operator/map';
import {HttpClient} from '@angular/common/http';
import {switchMap} from 'rxjs/operator/switchMap';
import {toArray} from 'rxjs/operator/toArray';
import {LoadSuccess} from '../actions/list';
import {_do} from 'rxjs/operator/do';
import {fromPromise} from 'rxjs/observable/fromPromise';
import {catchError} from 'rxjs/operators';
import {of} from 'rxjs/observable/of';

@Injectable()
export class ListEffects {

  @Effect()
  fetch$: Observable<Action> = Observable.create(function (observer) {
    console.log(observer);
    console.log('success');
    observer.next(new LoadSuccess([1, 2, 3]));
  });

  constructor(private actions$: Actions, private http: HttpClient) {
  }

}
