import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {routes} from './routes';
import {AppComponent} from './app.component';
import {IndexComponent} from './index/index.component';
import {StoreModule} from '@ngrx/store';
import {todos} from './reducers/todos';
import {ModelDemoComponent} from './model-demo/model-demo.component';
import {modelNum} from './reducers/modelNum';
import { ListComponent } from './list/list.component';


@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    ModelDemoComponent,
    ListComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    StoreModule.forRoot({todos, modelNum})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
