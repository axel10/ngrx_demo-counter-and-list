import {Action} from '@ngrx/store';

export class Load implements Action {
  readonly type = 'LOAD';
}

export class LoadSuccess implements Action {
  readonly type = 'LOAD_SUCCESS';

  constructor(public payload: number[]) {
  }
}
