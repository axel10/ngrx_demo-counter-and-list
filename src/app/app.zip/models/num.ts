export class Num {
  count: number;

  constructor(num: number) {
    this.count = num;
  }
}
